
# @client.command()
# async def rule(ctx,*,number):
#     await ctx.send(rules[int(number)-1])
